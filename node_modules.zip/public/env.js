window.env = {
  "REACT_APP_EMAILJS_SERVICE_ID": "service_6vlunsi",
  "REACT_APP_EMAILJS_PUBLIC_KEY": "vJ9Erm3lmJ6P9qrY_"
};